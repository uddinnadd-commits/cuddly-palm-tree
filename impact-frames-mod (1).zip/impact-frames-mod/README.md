# Impact Frames (Forge 1.20.1)

Anime-style **impact frames** whenever you land a **critical hit on the 5th hit of a mob**,
plus an **ULTRAKILL-inspired** flash / hit-stop look with a style popup.

> ⚠️ **Photosensitivity warning:** this mod produces rapid black/white flicker and bright flashes.
> Turn on `reduceFlashing` in the client config if that is a problem for you or your players.

## How it triggers

* Every melee hit you land on the same mob is counted (per mob, per player).
* On the **5th hit** the counter resets, and **if that hit was a critical hit** (jump/fall crit), the effect plays.
* If you stop hitting a mob for 5 seconds its counter resets.
* Everything is configurable (hits needed, crit required or not, timeout, PvP).

## The two looks

| Style | What you see |
|---|---|
| `CLASSIC` | Hard black/white inverted frames, Sobel outlines and radial speed lines that re-roll every frame (the classic anime impact frame). |
| `ULTRAKILL` | White parry-style flash, red/black/bone duotone with chunky pixelation + posterize, chromatic split and a blood-red vignette that decays out, a `+ CRITICAL` / `+ FINISHER` style popup, FOV punch and camera shake. |
| `COMBINED` (default) | `CLASSIC` frames, then the `ULTRAKILL` flash + decay. |
| `ALTERNATE` | Swaps between the two on every trigger. |

A **killing blow** on the 5th hit plays slower/heavier and says `+ FINISHER`.

The effect is a client-side post-processing shader that runs *before* the HUD is drawn, so your hotbar and health stay readable.

## Config

Files are generated in `config/` on first launch.

`impactframes-common.toml` (server / singleplayer rules)

| Option | Default | Meaning |
|---|---|---|
| `hitsRequired` | `5` | Every Nth hit on the same mob is the finisher |
| `requireCritical` | `true` | Finisher must also be a crit |
| `comboTimeoutTicks` | `100` | Ticks without hitting a mob before its counter resets |
| `includePlayers` | `false` | Count PvP hits too |

`impactframes-client.toml` (visuals)

| Option | Default | Meaning |
|---|---|---|
| `enabled` | `true` | Master switch |
| `style` | `COMBINED` | `CLASSIC`, `ULTRAKILL`, `COMBINED`, `ALTERNATE` |
| `intensity` | `1.0` | 0.0 – 1.0 overall strength |
| `reduceFlashing` | `false` | Photosensitive-safe mode (soft red fade only, no flicker/flash/shake) |
| `cameraShake` | `true` | FOV punch + shake |
| `stylePopup` | `true` | `+ CRITICAL` popup |
| `playSound` | `true` | Thud / boom |

## Preview command (client-side)

```
/impactframes test
/impactframes test classic
/impactframes test ultrakill lethal
/impactframes test combined lethal
```

## Multiplayer

Install on the server for the logic and on clients for the visuals. The network channel accepts
missing remotes, so vanilla / unmodded clients can still join a server that has the mod.

## Building

Needs **JDK 17**.

```bash
./gradlew build
```

The jar ends up in `build/libs/impactframes-1.0.0.jar` (already reobfuscated for production).

### On GitHub

1. Push this folder to a GitHub repo (keep `.github/workflows/build.yml`).
2. Every push / PR runs **Actions → Build** and uploads the jar as an artifact (`impact-frames-jar`).
   The workflow installs Gradle 8.8 itself, so it does not depend on `gradle-wrapper.jar` being committed.
3. Push a tag such as `v1.0.0` to also publish a **GitHub Release** with the jar attached:
   ```bash
   git tag v1.0.0 && git push origin v1.0.0
   ```

## Make it yours

* Change `mod_id`, `mod_name`, `mod_authors`, `mod_version` and `mod_group_id` in `gradle.properties`.
* The Java package is `com.example.impactframes`; rename it with your IDE's refactor tool.
  If you change the mod id, also change `MOD_ID` in `ImpactFramesMod.java` and the
  `impactframes` folder under `src/main/resources/assets/` (and the `impactframes:` names inside the shader JSON files).
* To tweak the look, edit the timelines at the top of `ImpactFrameManager.java` or the GLSL in
  `assets/impactframes/shaders/program/`. Press **F3 + T** in game to reload shaders without restarting.

## Notes

* Inspired by ULTRAKILL's look; not affiliated with or endorsed by New Blood Interactive / Arsi "Hakita" Patala. No game assets are used.
* There is no real world-freeze hit-stop: the look is simulated with the flash/pixel frames.

## License

MIT
