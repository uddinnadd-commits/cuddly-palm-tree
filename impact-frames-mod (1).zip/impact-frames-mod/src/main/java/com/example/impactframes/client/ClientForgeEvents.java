package com.example.impactframes.client;

import com.example.impactframes.ImpactFramesMod;
import com.example.impactframes.config.ImpactStyle;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.util.Mth;
import net.minecraft.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ImpactFramesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {

    private ClientForgeEvents() {}

    /** Runs after the world (and hand) is rendered but before the HUD, so the HUD is not affected. */
    @SubscribeEvent
    public static void onRenderGuiPre(RenderGuiEvent.Pre event) {
        ImpactFrameManager.renderEffect(event.getPartialTick());
    }

    @SubscribeEvent
    public static void onRenderGuiPost(RenderGuiEvent.Post event) {
        ImpactFrameManager.renderPopup(event.getGuiGraphics());
    }

    @SubscribeEvent
    public static void onComputeFov(ViewportEvent.ComputeFov event) {
        float punch = ImpactFrameManager.punch();
        if (punch > 0f) {
            event.setFOV(event.getFOV() * (1.0D - 0.10D * punch));
        }
    }

    @SubscribeEvent
    public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        float punch = ImpactFrameManager.punch();
        if (punch > 0f) {
            float t = Util.getMillis() * 0.09f;
            event.setPitch(event.getPitch() + Mth.sin(t * 1.7f) * 1.2f * punch);
            event.setYaw(event.getYaw() + Mth.cos(t * 2.3f) * 1.2f * punch);
            event.setRoll(event.getRoll() + Mth.sin(t * 3.1f) * 2.0f * punch);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ImpactFrameManager.reset();
    }

    /**
     * /impactframes test [classic|ultrakill|combined] [lethal]
     * Client-side command, so you can preview the effect without landing five hits.
     */
    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        LiteralArgumentBuilder<CommandSourceStack> test = Commands.literal("test")
                .executes(ctx -> run(false, null))
                .then(Commands.literal("lethal").executes(ctx -> run(true, null)));

        for (ImpactStyle style : new ImpactStyle[]{ImpactStyle.CLASSIC, ImpactStyle.ULTRAKILL, ImpactStyle.COMBINED}) {
            test.then(Commands.literal(style.name().toLowerCase(Locale.ROOT))
                    .executes(ctx -> run(false, style))
                    .then(Commands.literal("lethal").executes(ctx -> run(true, style))));
        }

        event.getDispatcher().register(Commands.literal("impactframes").then(test));
    }

    private static int run(boolean lethal, ImpactStyle style) {
        ImpactFrameManager.trigger(lethal, style);
        return 1;
    }
}
