package com.example.impactframes.client;

import com.example.impactframes.ImpactFramesMod;
import com.example.impactframes.config.ImpactConfig;
import com.example.impactframes.config.ImpactStyle;
import com.google.gson.JsonSyntaxException;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import java.util.Random;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;

/**
 * Client-side impact frame player.
 *
 * Two vanilla {@link PostChain}s (see assets/impactframes/shaders) are run on top of the finished
 * world image, right before the HUD is drawn, so the HUD stays readable. A tiny timeline decides
 * which chain runs and which uniforms are set for every rendered frame.
 */
public final class ImpactFrameManager {

    private static final ResourceLocation CLASSIC_CHAIN =
            new ResourceLocation(ImpactFramesMod.MOD_ID, "shaders/post/impact_classic.json");
    private static final ResourceLocation ULTRAKILL_CHAIN =
            new ResourceLocation(ImpactFramesMod.MOD_ID, "shaders/post/impact_ultrakill.json");

    // ------------------------------------------------------------------ timeline

    /** One held "anime" frame. */
    private record ClassicFrame(float durationMs, boolean negative, float burst, float mix) {}

    private static final ClassicFrame[] CLASSIC_FRAMES = {
            new ClassicFrame(45f, true, 1.00f, 1.00f),   // white lines on black
            new ClassicFrame(45f, false, 0.85f, 1.00f),  // black lines on white
            new ClassicFrame(45f, true, 0.65f, 1.00f),
            new ClassicFrame(35f, false, 0.30f, 0.85f),
            new ClassicFrame(30f, true, 0.00f, 0.50f),   // fades back into the scene
    };
    private static final float CLASSIC_TOTAL;

    static {
        float total = 0f;
        for (ClassicFrame frame : CLASSIC_FRAMES) {
            total += frame.durationMs();
        }
        CLASSIC_TOTAL = total;
    }

    // ULTRAKILL timeline (ms)
    private static final float ULTRA_FLASH_END = 40f;   // pure white flash
    private static final float ULTRA_HOLD_END = 120f;   // red duotone + pixelation "hit-stop" look
    private static final float ULTRA_TOTAL = 420f;      // then everything decays

    private static final long POPUP_MS = 1100L;

    // ------------------------------------------------------------------ state

    private static final Random RANDOM = new Random();

    private static PostChain classicChain;
    private static PostChain ultraChain;
    private static boolean loadFailed;
    private static int chainWidth = -1;
    private static int chainHeight = -1;

    private static long startMs = -1L;
    private static boolean runClassic;
    private static boolean runUltra;
    private static boolean reduced;
    private static boolean lethal;
    private static boolean shakeEnabled;
    private static float timeScale = 1f;
    private static float intensity = 1f;
    private static int seedBase;
    private static boolean alternateFlag;

    private static long popupStart = -1L;
    private static String popupText = "";

    private ImpactFrameManager() {}

    // ------------------------------------------------------------------ public api

    /**
     * Starts the effect.
     *
     * @param lethalHit     true if the hit that triggered it killed the mob (plays longer / harder)
     * @param styleOverride forces a style (used by the test command), null = use the config value
     */
    public static void trigger(boolean lethalHit, ImpactStyle styleOverride) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            return;
        }
        ImpactConfig.Client cfg = ImpactConfig.CLIENT;
        if (!cfg.enabled.get() || cfg.intensity.get() <= 0.0D) {
            return;
        }

        ImpactStyle style = styleOverride != null ? styleOverride : cfg.style.get();
        if (style == ImpactStyle.ALTERNATE) {
            alternateFlag = !alternateFlag;
            style = alternateFlag ? ImpactStyle.CLASSIC : ImpactStyle.ULTRAKILL;
        }

        reduced = cfg.reduceFlashing.get();
        runClassic = !reduced && (style == ImpactStyle.CLASSIC || style == ImpactStyle.COMBINED);
        runUltra = reduced || style == ImpactStyle.ULTRAKILL || style == ImpactStyle.COMBINED;

        lethal = lethalHit;
        timeScale = lethalHit ? 1.3f : 1.0f;
        intensity = cfg.intensity.get().floatValue();
        shakeEnabled = cfg.cameraShake.get() && !reduced;
        seedBase = RANDOM.nextInt(1000);
        startMs = Util.getMillis();

        if (runUltra && cfg.stylePopup.get()) {
            popupStart = startMs;
            popupText = lethalHit ? "+ FINISHER" : "+ CRITICAL";
        }
        if (cfg.playSound.get()) {
            playSounds(mc, lethalHit);
        }
    }

    /** Called every frame just before the HUD is drawn. */
    public static void renderEffect(float partialTick) {
        if (startMs < 0L) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            startMs = -1L;
            return;
        }

        float elapsed = (Util.getMillis() - startMs) / timeScale;
        float classicLen = runClassic ? CLASSIC_TOTAL : 0f;
        float ultraLen = runUltra ? ULTRA_TOTAL : 0f;

        if (elapsed >= classicLen + ultraLen) {
            startMs = -1L;
            return;
        }

        if (elapsed < classicLen) {
            renderClassic(mc, elapsed, partialTick);
        } else {
            renderUltrakill(mc, elapsed - classicLen, partialTick);
        }
    }

    /** Draws the "+ CRITICAL" style popup. Called after the HUD. */
    public static void renderPopup(GuiGraphics g) {
        if (popupStart < 0L) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        long age = Util.getMillis() - popupStart;
        if (age > POPUP_MS) {
            popupStart = -1L;
            return;
        }
        if (mc.options.hideGui) {
            return;
        }

        float slide = 1f - Mth.clamp(age / 120f, 0f, 1f);
        float fadeStart = POPUP_MS - 300f;
        float fade = age < fadeStart ? 1f : 1f - (age - fadeStart) / 300f;
        int alpha = Mth.clamp((int) (fade * 255f), 0, 255);
        if (alpha < 8) {
            return;
        }

        Font font = mc.font;
        float scale = 2.0f;
        int textW = Mth.ceil(font.width(popupText) * scale);
        int textH = Mth.ceil(font.lineHeight * scale);
        int x = g.guiWidth() - textW - 14 + Mth.floor(slide * 90f);
        int y = g.guiHeight() / 2 - 50;

        int panelAlpha = ((int) (alpha * 0.55f)) << 24;
        g.fill(x - 8, y - 4, x + textW + 14, y + textH + 4, panelAlpha);
        g.fill(x - 8, y - 4, x - 5, y + textH + 4, (alpha << 24) | 0xE02010);

        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, popupText, 0, 0, (alpha << 24) | (lethal ? 0xFFD040 : 0xFF3A1E), true);
        g.pose().popPose();
    }

    /** 0..~1.35 camera "punch" strength used for the shake and FOV kick. */
    public static float punch() {
        if (startMs < 0L || !shakeEnabled) {
            return 0f;
        }
        float elapsed = (Util.getMillis() - startMs) / timeScale;
        float p = 1f - Mth.clamp(elapsed / 320f, 0f, 1f);
        return p * p * (lethal ? 1.35f : 1.0f);
    }

    /** Drops any running effect (e.g. when leaving a world). */
    public static void reset() {
        startMs = -1L;
        popupStart = -1L;
    }

    /** Frees GPU resources; they are rebuilt lazily. Called on resource reload (F3+T). */
    public static void invalidate() {
        closeQuietly(classicChain);
        closeQuietly(ultraChain);
        classicChain = null;
        ultraChain = null;
        loadFailed = false;
        chainWidth = -1;
        chainHeight = -1;
    }

    // ------------------------------------------------------------------ rendering

    private static void renderClassic(Minecraft mc, float elapsed, float partialTick) {
        PostChain chain = getChain(mc, true);
        if (chain == null) {
            return;
        }

        int index = 0;
        float t = elapsed;
        while (index < CLASSIC_FRAMES.length - 1 && t >= CLASSIC_FRAMES[index].durationMs()) {
            t -= CLASSIC_FRAMES[index].durationMs();
            index++;
        }
        ClassicFrame frame = CLASSIC_FRAMES[index];

        chain.setUniform("Negative", frame.negative() ? 1f : 0f);
        chain.setUniform("Threshold", 0.42f);
        chain.setUniform("Burst", frame.burst());
        chain.setUniform("Seed", ((seedBase + index * 31) % 100) * 0.173f);
        chain.setUniform("Mix", frame.mix() * intensity);

        runChain(mc, chain, partialTick);
    }

    private static void renderUltrakill(Minecraft mc, float u, float partialTick) {
        PostChain chain = getChain(mc, false);
        if (chain == null) {
            return;
        }

        float flash = 0f;
        float duotone = 0f;
        float pixel = 0f;
        float posterize = 0f;
        float vignette = 0f;
        float aberration = 0f;

        if (reduced) {
            // Photosensitive-safe: only a soft red vignette fading out.
            float p = Mth.clamp(u / ULTRA_TOTAL, 0f, 1f);
            vignette = 0.7f * (1f - p) * (1f - p);
        } else if (u < ULTRA_FLASH_END) {
            flash = 1f;
        } else if (u < ULTRA_HOLD_END) {
            duotone = 1f;
            pixel = 8f;
            posterize = 3f;
            vignette = 1f;
            aberration = 8f;
        } else {
            float p = Mth.clamp((u - ULTRA_HOLD_END) / (ULTRA_TOTAL - ULTRA_HOLD_END), 0f, 1f);
            float k = (1f - p) * (1f - p);
            duotone = p < 0.30f ? 1f - p / 0.30f : 0f;
            posterize = p < 0.30f ? 4f : 0f;
            pixel = p < 0.15f ? 6f : (p < 0.30f ? 4f : (p < 0.45f ? 2f : 0f));
            vignette = k;
            aberration = 8f * k;
        }

        chain.setUniform("Flash", flash * intensity);
        chain.setUniform("Duotone", duotone * intensity);
        chain.setUniform("Pixel", pixel);
        chain.setUniform("Posterize", posterize);
        chain.setUniform("Vignette", vignette * intensity);
        chain.setUniform("Aberration", aberration * intensity);

        runChain(mc, chain, partialTick);
    }

    private static void runChain(Minecraft mc, PostChain chain, float partialTick) {
        // Same GL state vanilla uses around GameRenderer's own post effects.
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();

        chain.process(partialTick);

        // PostChain leaves framebuffer 0 bound; give the HUD the main target back.
        mc.getMainRenderTarget().bindWrite(true);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
    }

    private static PostChain getChain(Minecraft mc, boolean classic) {
        if (loadFailed) {
            return null;
        }
        int w = mc.getWindow().getWidth();
        int h = mc.getWindow().getHeight();

        try {
            if (classic) {
                if (classicChain == null) {
                    classicChain = load(mc, CLASSIC_CHAIN, w, h);
                }
            } else if (ultraChain == null) {
                ultraChain = load(mc, ULTRAKILL_CHAIN, w, h);
            }
        } catch (IOException | JsonSyntaxException e) {
            ImpactFramesMod.LOGGER.error("Impact Frames: could not load the {} shader chain. "
                    + "The effect is disabled until the next resource reload (F3+T).", classic ? "classic" : "ultrakill", e);
            loadFailed = true;
            return null;
        }

        if (w != chainWidth || h != chainHeight) {
            if (classicChain != null) {
                classicChain.resize(w, h);
            }
            if (ultraChain != null) {
                ultraChain.resize(w, h);
            }
            chainWidth = w;
            chainHeight = h;
        }
        return classic ? classicChain : ultraChain;
    }

    private static PostChain load(Minecraft mc, ResourceLocation location, int w, int h) throws IOException {
        PostChain chain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(), location);
        chain.resize(w, h);
        return chain;
    }

    private static void closeQuietly(PostChain chain) {
        if (chain != null) {
            try {
                chain.close();
            } catch (Exception ignored) {
                // nothing sensible to do if the GL objects are already gone
            }
        }
    }

    // ------------------------------------------------------------------ audio

    private static void playSounds(Minecraft mc, boolean lethalHit) {
        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();
        mc.level.playLocalSound(x, y, z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS,
                0.45f, lethalHit ? 0.7f : 1.2f, false);
        if (lethalHit) {
            mc.level.playLocalSound(x, y, z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS,
                    0.25f, 1.6f, false);
        }
    }
}
