package com.example.impactframes.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public final class ImpactConfig {
    public static final Common COMMON;
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        Pair<Common, ForgeConfigSpec> common = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = common.getLeft();
        COMMON_SPEC = common.getRight();

        Pair<Client, ForgeConfigSpec> client = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = client.getLeft();
        CLIENT_SPEC = client.getRight();
    }

    private ImpactConfig() {}

    /** Gameplay rules. Read by the server (or the integrated server in singleplayer). */
    public static final class Common {
        public final ForgeConfigSpec.IntValue hitsRequired;
        public final ForgeConfigSpec.BooleanValue requireCritical;
        public final ForgeConfigSpec.IntValue comboTimeoutTicks;
        public final ForgeConfigSpec.BooleanValue includePlayers;

        Common(ForgeConfigSpec.Builder b) {
            b.comment("When do the impact frames trigger?").push("trigger");

            hitsRequired = b
                    .comment("Every Nth melee hit on the same mob is the 'finisher' hit. Default: 5")
                    .defineInRange("hitsRequired", 5, 1, 50);

            requireCritical = b
                    .comment("The finisher hit must also be a critical hit (falling / jump crit) to trigger the effect.",
                            "If false, every Nth hit triggers it.")
                    .define("requireCritical", true);

            comboTimeoutTicks = b
                    .comment("If you stop hitting a mob for this many ticks (20 = 1 second) its hit counter resets.")
                    .defineInRange("comboTimeoutTicks", 100, 20, 6000);

            includePlayers = b
                    .comment("Also count hits on other players (PvP).")
                    .define("includePlayers", false);

            b.pop();
        }
    }

    /** Visual / audio options. Only used on the client. */
    public static final class Client {
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.EnumValue<ImpactStyle> style;
        public final ForgeConfigSpec.DoubleValue intensity;
        public final ForgeConfigSpec.BooleanValue reduceFlashing;
        public final ForgeConfigSpec.BooleanValue cameraShake;
        public final ForgeConfigSpec.BooleanValue stylePopup;
        public final ForgeConfigSpec.BooleanValue playSound;

        Client(ForgeConfigSpec.Builder b) {
            b.comment("Impact frame visuals").push("visuals");

            enabled = b
                    .comment("Master switch for the visual effect.")
                    .define("enabled", true);

            style = b
                    .comment("CLASSIC   = anime black/white impact frames with speed lines",
                            "ULTRAKILL = flash + red duotone + pixelation + blood vignette",
                            "COMBINED  = classic frames, then the ULTRAKILL flash/decay",
                            "ALTERNATE = swaps between CLASSIC and ULTRAKILL each trigger")
                    .defineEnum("style", ImpactStyle.COMBINED);

            intensity = b
                    .comment("Overall strength of the effect (0.0 - 1.0).")
                    .defineInRange("intensity", 1.0D, 0.0D, 1.0D);

            reduceFlashing = b
                    .comment("PHOTOSENSITIVITY OPTION: removes the rapid black/white flicker, the white flash",
                            "and the camera shake. Only a soft red vignette fade is shown.")
                    .define("reduceFlashing", false);

            cameraShake = b
                    .comment("Small camera shake + FOV punch on trigger.")
                    .define("cameraShake", true);

            stylePopup = b
                    .comment("Show the ULTRAKILL-style '+ CRITICAL' / '+ FINISHER' popup on the right of the screen.")
                    .define("stylePopup", true);

            playSound = b
                    .comment("Play a heavy thud (and a boom on killing blows) when the effect triggers.")
                    .define("playSound", true);

            b.pop();
        }
    }
}
