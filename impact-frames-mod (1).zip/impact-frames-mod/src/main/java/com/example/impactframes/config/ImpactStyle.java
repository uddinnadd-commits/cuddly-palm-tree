package com.example.impactframes.config;

/** Which impact-frame look(s) get played when the combo triggers. */
public enum ImpactStyle {
    /** Anime-style black/white inverted frames with speed lines. */
    CLASSIC,
    /** ULTRAKILL-inspired flash, red duotone, pixelation and vignette. */
    ULTRAKILL,
    /** Classic frames first, then the ULTRAKILL flash/decay right after. */
    COMBINED,
    /** Switches between CLASSIC and ULTRAKILL every trigger. */
    ALTERNATE
}
