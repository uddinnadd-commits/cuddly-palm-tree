package com.example.impactframes.network;

import com.example.impactframes.client.ImpactFrameManager;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Server -> client: "play the impact frames now". */
public record ImpactFramePacket(boolean lethal) {

    public static void encode(ImpactFramePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.lethal());
    }

    public static ImpactFramePacket decode(FriendlyByteBuf buf) {
        return new ImpactFramePacket(buf.readBoolean());
    }

    public static void handle(ImpactFramePacket msg, Supplier<NetworkEvent.Context> ctx) {
        // Already on the main thread (registered with consumerMainThread).
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ImpactFrameManager.trigger(msg.lethal(), null));
    }
}
