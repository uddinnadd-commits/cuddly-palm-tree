package com.example.impactframes.network;

import com.example.impactframes.ImpactFramesMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    // acceptMissingOr(...) lets vanilla clients / clients without the mod still join a server that has it.
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ImpactFramesMod.MOD_ID, "main"),
            () -> PROTOCOL,
            NetworkRegistry.acceptMissingOr(PROTOCOL),
            NetworkRegistry.acceptMissingOr(PROTOCOL)
    );

    private ModNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(ImpactFramePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ImpactFramePacket::encode)
                .decoder(ImpactFramePacket::decode)
                .consumerMainThread(ImpactFramePacket::handle)
                .add();
    }
}
