package com.example.impactframes.server;

import com.example.impactframes.ImpactFramesMod;
import com.example.impactframes.config.ImpactConfig;
import com.example.impactframes.network.ImpactFramePacket;
import com.example.impactframes.network.ModNetwork;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.CriticalHitEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * Server-side combo logic.
 *
 * Flow of a single melee attack (all inside one server tick):
 *   1. Player#attack fires {@link CriticalHitEvent}  -> we remember whether it was a crit.
 *   2. The target is hurt and {@link LivingDamageEvent} fires -> we count the hit,
 *      and on every Nth hit (that is also a crit, if required) we tell the client to play the effect.
 */
@Mod.EventBusSubscriber(modid = ImpactFramesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class HitTracker {

    private static final class HitRecord {
        int hits;
        long lastHitTick;
    }

    private record PendingCrit(UUID target, long tick, boolean crit) {}

    /** player uuid -> (mob uuid -> hit record) */
    private static final Map<UUID, Map<UUID, HitRecord>> HITS = new HashMap<>();
    private static final Map<UUID, PendingCrit> PENDING = new HashMap<>();

    private HitTracker() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onCriticalHit(CriticalHitEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || !(player instanceof ServerPlayer) || player instanceof FakePlayer) {
            return;
        }

        // Same rule Forge uses internally: ALLOW forces a crit, DEFAULT falls back to vanilla's decision.
        boolean crit = event.getResult() == Event.Result.ALLOW
                || (event.getResult() == Event.Result.DEFAULT && event.isVanillaCritical());

        PENDING.put(player.getUUID(),
                new PendingCrit(event.getTarget().getUUID(), player.level().getGameTime(), crit));
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDamage(LivingDamageEvent event) {
        DamageSource source = event.getSource();
        if (!(source.getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }
        // Melee only: ignore arrows, tridents, etc.
        if (source.getDirectEntity() != player) {
            return;
        }

        LivingEntity target = event.getEntity();
        long now = player.level().getGameTime();

        // Always consume the pending crit flag so it can never leak onto a later hit.
        PendingCrit pending = PENDING.remove(player.getUUID());

        if (!isValidTarget(target, player) || event.getAmount() <= 0.0F) {
            return;
        }

        boolean crit = pending != null
                && pending.crit()
                && pending.tick() == now
                && pending.target().equals(target.getUUID());

        int timeout = ImpactConfig.COMMON.comboTimeoutTicks.get();
        Map<UUID, HitRecord> records = HITS.computeIfAbsent(player.getUUID(), id -> new HashMap<>());
        if (records.size() > 64) {
            records.values().removeIf(r -> now - r.lastHitTick > timeout);
        }

        HitRecord record = records.computeIfAbsent(target.getUUID(), id -> new HitRecord());
        if (record.hits > 0 && now - record.lastHitTick > timeout) {
            record.hits = 0;
        }
        record.hits++;
        record.lastHitTick = now;

        if (record.hits < ImpactConfig.COMMON.hitsRequired.get()) {
            return;
        }

        // This was the Nth hit: reset the counter either way, so it is "every 5th hit".
        record.hits = 0;

        if (ImpactConfig.COMMON.requireCritical.get() && !crit) {
            return;
        }

        boolean lethal = target.getHealth() - event.getAmount() <= 0.0F;
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ImpactFramePacket(lethal));
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide()) {
            return;
        }
        UUID dead = event.getEntity().getUUID();
        HITS.values().forEach(map -> map.remove(dead));
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        HITS.remove(id);
        PENDING.remove(id);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        HITS.clear();
        PENDING.clear();
    }

    private static boolean isValidTarget(LivingEntity target, ServerPlayer attacker) {
        if (target == attacker) {
            return false;
        }
        if (target instanceof Player) {
            return ImpactConfig.COMMON.includePlayers.get();
        }
        return target instanceof Mob;
    }
}
