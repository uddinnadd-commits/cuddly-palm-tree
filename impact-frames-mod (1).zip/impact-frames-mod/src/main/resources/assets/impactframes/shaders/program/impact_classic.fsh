#version 150

// Anime-style impact frame:
//  - hard luminance threshold (flat black / white shapes)
//  - Sobel outlines
//  - radial speed lines that re-roll every frame
//  - optional negative (inverted) version

uniform sampler2D DiffuseSampler;

uniform vec2 OutSize;
uniform float Negative;   // 0 = black ink on white paper, 1 = white ink on black
uniform float Threshold;  // luminance cut-off between paper and ink
uniform float Burst;      // 0..1 strength of the radial speed lines
uniform float Seed;       // changes per impact frame so the lines jitter
uniform float Mix;        // 0..1 blend between the real scene and the effect

in vec2 texCoord;

out vec4 fragColor;

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float hash(float n) {
    return fract(sin(n * 12.9898 + Seed * 78.233) * 43758.5453);
}

void main() {
    vec4 scene = texture(DiffuseSampler, texCoord);

    // Sample spacing grows with resolution so the lines keep the same look at 1080p / 4K.
    float scale = max(1.0, OutSize.y / 540.0);
    vec2 px = vec2(scale) / OutSize;

    float tl = luma(texture(DiffuseSampler, texCoord + px * vec2(-1.0, -1.0)).rgb);
    float tc = luma(texture(DiffuseSampler, texCoord + px * vec2( 0.0, -1.0)).rgb);
    float tr = luma(texture(DiffuseSampler, texCoord + px * vec2( 1.0, -1.0)).rgb);
    float ml = luma(texture(DiffuseSampler, texCoord + px * vec2(-1.0,  0.0)).rgb);
    float mc = luma(scene.rgb);
    float mr = luma(texture(DiffuseSampler, texCoord + px * vec2( 1.0,  0.0)).rgb);
    float bl = luma(texture(DiffuseSampler, texCoord + px * vec2(-1.0,  1.0)).rgb);
    float bc = luma(texture(DiffuseSampler, texCoord + px * vec2( 0.0,  1.0)).rgb);
    float br = luma(texture(DiffuseSampler, texCoord + px * vec2( 1.0,  1.0)).rgb);

    // Sobel edge detection
    float gx = (tr + 2.0 * mr + br) - (tl + 2.0 * ml + bl);
    float gy = (bl + 2.0 * bc + br) - (tl + 2.0 * tc + tr);
    float edge = sqrt(gx * gx + gy * gy);

    // Blurred tone so block textures don't turn into noise
    float tone = (tl + tc + tr + ml + mc + mr + bl + bc + br) / 9.0;

    float paper = step(Threshold, tone);        // 1 = light area
    float outline = step(0.6, edge);            // 1 = outline pixel
    float ink = max(1.0 - paper, outline);      // 1 = ink

    // Radial speed lines
    vec2 p = (texCoord - 0.5) * vec2(OutSize.x / OutSize.y, 1.0);
    float angle = (atan(p.y, p.x) + 3.14159265) / 6.2831853;
    float spokes = 90.0;
    float spokeId = floor(angle * spokes);
    float within = fract(angle * spokes);
    float radius = length(p);

    float inner = 0.12 + 0.35 * hash(spokeId);
    float present = step(0.5, hash(spokeId + 31.0));
    float halfWidth = abs(within - 0.5) * 2.0;
    float reach = clamp((radius - inner) * 2.2, 0.0, 1.0) * Burst;
    float spoke = present * step(inner, radius) * step(halfWidth, reach * 0.8);

    ink = max(ink, spoke);

    float v = mix(1.0 - ink, ink, Negative);

    fragColor = vec4(mix(scene.rgb, vec3(v), Mix), 1.0);
}
