#version 150

// ULTRAKILL-inspired hit look: white flash, red/black/white duotone,
// chunky "PS1" pixelation + posterize, chromatic split and a blood-red vignette.
// All values are driven from Java so they can be keyframed.

uniform sampler2D DiffuseSampler;

uniform vec2 OutSize;
uniform float Flash;       // 0..1 white flash
uniform float Duotone;     // 0..1 amount of red/black/white duotone
uniform float Pixel;       // block size in pixels at 720p (<= 1 = off)
uniform float Posterize;   // colour levels per channel (<= 1 = off)
uniform float Vignette;    // 0..1 red vignette
uniform float Aberration;  // chromatic split in pixels at the screen edge

in vec2 texCoord;

out vec4 fragColor;

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

void main() {
    vec2 uv = texCoord;

    if (Pixel > 1.0) {
        float blockPx = Pixel * max(1.0, OutSize.y / 720.0);
        vec2 cells = OutSize / blockPx;
        uv = (floor(uv * cells) + 0.5) / cells;
    }

    vec2 dir = uv - 0.5;
    vec2 shift = dir * 2.0 * Aberration / OutSize;

    vec3 col;
    col.r = texture(DiffuseSampler, uv + shift).r;
    col.g = texture(DiffuseSampler, uv).g;
    col.b = texture(DiffuseSampler, uv - shift).b;

    if (Posterize > 1.0) {
        col = floor(col * Posterize + 0.5) / Posterize;
    }

    // black -> blood red -> bone white
    float l = luma(col);
    vec3 duo = mix(vec3(0.0), vec3(0.85, 0.04, 0.02), step(0.20, l));
    duo = mix(duo, vec3(1.0, 0.93, 0.80), step(0.62, l));
    col = mix(col, duo, Duotone);

    // red vignette
    float d = length(dir) * 1.41421356;
    float vig = smoothstep(0.30, 1.0, d) * Vignette;
    col = mix(col, vec3(0.75, 0.0, 0.0), vig * 0.85);

    // parry-style white flash
    col = mix(col, vec3(1.0), Flash);

    fragColor = vec4(col, 1.0);
}
